from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import User
from django.http import HttpResponse


class LoginView(APIView):

    def post(self, request, *args, **kwargs):
        """this is the function to log in"""
        print("这个登录包里的数据: ", request.data)
        if request.method == "POST":
            print("开始登录了嗷")
            # 从包里读出相应数据
            thisUserCode = request.POST['userid']
            thisUserName = request.POST['username']
            # thisUserPlace = request.POST['user_place']
            # thisUserCode = request.POST['code_sub']
            # User.objects.create(userId=thisUserId, userName=thisUserName, userPlace=thisUserPlace)
            theUsers = User.objects.all()

            print("提交的姓名: ", thisUserName)
            print("提交的记者证: ", thisUserCode)
            # print("提交的地址: ", thisUserPlace)
            # print("提交的密码: ", thisUserCode)
            print("存储的用户: ", theUsers)

            try:
                thisUser = User.objects.get(userName=thisUserName)
                if thisUser.userCode != thisUserCode:
                    print("密码不正确")
                    return Response({"密码不正确"})

            except User.DoesNotExist as e:
                print("用户不存在")
                return Response({"用户不存在"})

            print("登陆成功")
            return Response({"登陆成功"})
        else:
            print("注册失败")
            return Response({"注册失败"})


class SignupView(APIView):

    def post(self, request):
        """this is the function to sign up"""
        print("这个注册包里的数据: ", request.data)
        if request.method == "POST":
            print("开始注册了嗷")
            # 从包里读出响应数据
            thisUserId = request.POST['id_sub']
            thisUserName = request.POST['username_sub']
            thisUserPlace = request.POST['user_place']
            thisUserCode = request.POST['code_sub']

            print("提交的姓名: ", thisUserName)
            print("提交的记者证: ", thisUserId)
            print("提交的地址: ", thisUserPlace)
            print("提交的密码: ", thisUserCode)

            isId = User.objects.filter(userId=thisUserId)
            isName = User.objects.filter(userName=thisUserName)

            if isId.exists():  # 如果记者证存在，下一步
                print("记者证存在")
                if isName.exists():  # 如果该用户名存在，结束注册
                    print("该用户名已注册")
                    return Response({"该用户名已注册"})
                else:  # 如果用户名不存在，下一步
                    user = User.objects.get(userId=thisUserId)
                    user.userId = thisUserId
                    user.userName = thisUserName
                    user.userCode = thisUserCode
                    user.userPlace = thisUserPlace
                    user.save()
                    # user = User.objects.save(userId=thisUserId, userName=thisUserName, userCode=thisUserCode, userPlace=thisUserPlace)
                    print("注册成功")
                    return Response({"注册成功"})
            else:  # 如果记者证不存在，结束注册
                print("记者证不存在")
                return Response({"记者证不存在"})

        else:
            print("注册失败")
            return Response({"注册失败"})
