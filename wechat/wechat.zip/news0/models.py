from django.db import models


# Create your models here.
class User(models.Model):
    # 记者证、要唯一
    userId = models.CharField(max_length=20, blank=True)
    # 名字
    userName = models.CharField(max_length=20, blank=True)
    # 国家
    userPlace = models.CharField(max_length=20, blank=True)
    # 密码
    userCode = models.CharField(max_length=50, blank=True)

    @classmethod
    def createuser(cls, id_sub, username_sub, user_place, code_sub):
        u = cls(userId=id_sub, userName=username_sub, userPlace=user_place, userCode=code_sub)
        return u

    def __str__(self):
        return self.userId
