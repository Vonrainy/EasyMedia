Page({
  data: {},
  onLoad() {},
});
