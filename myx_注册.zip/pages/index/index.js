Page({
  travel(){
    dd.switchTab({
      url: '/pages/character/character'
    })
  }
});
