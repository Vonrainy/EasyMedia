Page({
  data: {
    username_sub:"",
    code_sub:"",
    id_sub:"",

    user_name:"",
    user_id:"",
    login_f:"",

    display:'',
    flag: true,

    array: ['中国', '美国', '巴西', '日本'],
    objectArray: [
      {
        id: 0,
        name: '美国',
      },
      {
        id: 1,
        name: '中国',
      },
      {
        id: 2,
        name: '巴西',
      },
      {
        id: 3,
        name: '日本',
      },
    ],
    arrIndex: 0,
    index: 0
  },
  onLoad() {},

  //closemask承担遮罩层去显示、注册按钮
  //重新书写fail里对于flag的变换，需要对应正确的逻辑，但是不需要时延！
  closeMask: function (e) {
    var that = this;
    dd.httpRequest({
       //
        url: 'http://127.0.0.1:8000/news0/login/',
        method: 'POST',
    // 需要手动调用JSON.stringify将数据进行序列化
        data: {
          id_sub: this.data.id_sub,
          username_sub: this.data.username_sub,
          user_place: this.data.array[this.data.index],
          code_sub:this.data.code_sub
        },
        success: function(res) {
          dd.alert({
            content:'注册成功',
            buttonText:'搞定',
            success(){
              that.setData({ flag: true });
              //dd.navigation()
            }
          });
        },
        fail: function(res) {
          dd.alert({content: '失败' ,buttonText:'麻了重来'});
          
        },
        complete: function(res) {
          dd.alert({content: 'complete'});
        }
        });
  },

//注册界面函数
  username_sub(e){
    this.setData({
      username_sub:e.detail.value
    })
  },

  code_sub(e){
    this.setData({
      code_sub:e.detail.value
    })
  },

  id_sub(e){
    this.setData({
      id_sub:e.detail.value
    })
  },

//登录界面函数
  username(e){
    this.setData({
      user_name:e.detail.value
    })
  },

  userid(e){
    this.setData({
      user_id: e.detail.value
    })
  },

  submit_button(e){
    var that = this;
    if (that.data.user_name == "" && that.data.user_id == ""){
      dd.alert({
        title: "你的身份证和记者证号未输入！",//可传空
        buttonText: '我知道了',
        success: () => {
        
      },
      });
    }
    else if(that.data.user_name == ""){
      dd.alert({
        title: "你的身份证未输入！",//可传空
        buttonText: '我知道了',
        success: () => {
        
      },
      });
    }
    else if(that.data.user_id == ""){
      dd.alert({
        title: "你的记者证未输入！",//可传空
        buttonText: '我知道了',
        success: () => {
        
      },
      });
    }
    else{
      
        dd.httpRequest({
       //
        url: 'http://127.0.0.1:8000/news0/login/',
        method: 'POST',
    // 需要手动调用JSON.stringify将数据进行序列化
        data: {
          userid: this.data.user_id,
          username: this.data.user_name,
        },
        success: function(res) {
          dd.alert({content: '登录成功',buttonText:'好！'});
          console.log(res);
          this.setData({
          login_f:res.data[0],
           });

           //if(res.data[0]=="false"){
            //用于起吊一个注册遮罩 if(this.data.login_f==”false“){...}
            //this.setData({ flag: false });
           //}
        },
        fail: function(res) {
          dd.alert({
            content: '未找到注册信息',
            buttonText:'麻了',
            success:function(){
              that.setData({ flag: false });
            }
          });
          console.log("wtf");
          console.log(res.data)
        },
        complete: function(res) {
          dd.alert({content: 'complete'});
        }
        });
    }

  },


});
